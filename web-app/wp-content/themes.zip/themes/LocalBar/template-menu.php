<?php

/*

Template Name: Menu

*/

?>



<?php get_header(); ?>
<?php get_footer(); ?>