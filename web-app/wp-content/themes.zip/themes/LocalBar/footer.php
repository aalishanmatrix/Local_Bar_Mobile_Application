<div data-role="footer" id="footer">
    &copy; <?php echo date('Y');?> Local Bar <br/>
       <span>All Right Reserved</span> 
       <div id="wine_bottles"></div>
</div>
</div> <!--page ends-->
<?php wp_footer(); ?>
</body>
</html>