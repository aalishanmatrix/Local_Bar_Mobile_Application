<div data-role="page" data-theme="b">
        <?php include("header_portion.php");?>
<div  data-role="content" id="content" data-theme="b"> 

<div id="index-image">
  	 <!-- it will be changed later  -->
  	<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/img.jpg"/>
</div>
<div class="home-caption">Welcome To Local Bar</div>
<div class="home-desc">Before electronic publishing, graphic designers had to mock up layouts by drawing in squiggled lines to indicate text. The advent of self-adhesive sheets preprinted with “Lorem ipsum” gave a more realistic way to indicate where text would go on a page.</div>
<br/>
<center>
<div class="social">
      <a href="#"><img src="<? url(); ?>/images/facebook.png"/></a>
      <a href="#"><img src="<? url(); ?>/images/twitter.png"/></a>
      <a href="#"><img src="<? url(); ?>/images/youtube.png"/></a> 
      <a href="#"><img src="<? url(); ?>/images/google_plus.png"/></a>
 </div>
 </center>
 <div id="wine_bottles"></div>
</div>

