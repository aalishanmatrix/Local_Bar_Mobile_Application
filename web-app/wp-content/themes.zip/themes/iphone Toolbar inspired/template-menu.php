<?php

/*

Template Name: Menu

*/

?>
<meta http-equiv="refresh" content="0;url=https://docs.google.com/gview?embedded=true&url=http://greenfiremarket.com/wp-content/uploads/2013/01/Menu.pdf" />