<div id="header" data-role="header">
        <div id="head_image_wrapper">
             <div id="head_image">
             </div>
        </div>
        <a href="<? bloginfo('url'); ?>" data-icon="home" class="ui-btn-left" data-iconpos="notext" id="menu" data-transition="flip">Home</a>
        <a href="tel:1234" data-icon="call" class="ui-btn-right" data-iconpos="notext" id="menu">Call</a>
</div>