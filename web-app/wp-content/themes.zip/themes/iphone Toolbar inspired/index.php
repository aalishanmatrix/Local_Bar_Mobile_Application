<?php get_header(); ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>

